You need to download the crex-roku package from
https://github.com/BlueBoxMoon/crex/Roku
and place the contents into the crex folder. The crex folder
itself should contain a number of files, including crex.version.txt
